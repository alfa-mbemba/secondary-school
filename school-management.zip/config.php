<?php
// InfinityFree Database Configuration
// MUHIMU: Hizi siyo credentials za localhost!
$host = 'sql123.infinityfree.com';     // Hostname yako kutoka dashboard
$user = 'if0_42132591_school_user';    // Username yako
$password = 'School@2024';              // Password uliyoweka
$database = 'if0_42132591_school_db';  // Jina la database yako

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>